
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

#define MAX_NODES 14001        //maximum no of nodes  
#define LABEL_LENGTH 200        //max length node label 
#define LINE_LENGTH 256         //max len of a line in input file

int adjMat[MAX_NODES][MAX_NODES]={0};//adjacency matrix 
char labels[MAX_NODES][LABEL_LENGTH]={{0}}; //node labels  

bool possible(int src,int destination){//check if the node is valid or not 
    return src>=0 && src<MAX_NODES && destination>=0 && destination<MAX_NODES;
}

void BuildGraph(const char* filename){//this function will build the graph from the file 
    FILE* file=fopen(filename,"r");
    if(!file){ //to check weather we can open the fike or not 
        perror("Error opening graph file");
        exit(EXIT_FAILURE);//return this that we coundlnt open the file 
    }
    char line[LINE_LENGTH];
    int line_num=0;
    while(fgets(line,sizeof(line),file)){
        line_num++;
        int src,destination;
        if(sscanf(line,"%d,%d",&src,&destination)==2){
            if(possible(src,destination)){//to check if they are valid or not 
                adjMat[src][destination]=1; //this is going to be an undirected graph.
                adjMat[destination][src]=1;
            } 


            else{
                fprintf(stderr,"Invalid edge at line %d:%d->%d\n",line_num,src,destination);
            }

        }
    }
    fclose(file);
}

void NodeMapping(const char* filename){//here we are mapping the nodes to the list 
    FILE* file=fopen(filename,"r"); //opening the file 
    if(!file){// Check if the file opened correctly
        perror("Error opening nodes file");
        exit(EXIT_FAILURE);
    }

    char line[LINE_LENGTH];
    int line_num=0;

    while(fgets(line,sizeof(line),file)){ //reading all the lines in the files
        line_num++;
        int node_Id;


        char label[LABEL_LENGTH];
        if(sscanf(line,"%d,%199[^\n]",&node_Id,label)==2){ //checking for validity 
            if(node_Id>=0 && node_Id<MAX_NODES){

                strncpy(labels[node_Id],label,LABEL_LENGTH-1);
                labels[node_Id][LABEL_LENGTH-1]='\0';
            } 
            else{
                fprintf(stderr,"Invalid node ID at line %d:%d\n",line_num,node_Id);
            }
        }
    }
    fclose(file);//close the file its a good practie 
}

//here we are declaring the global variables here 
int pathLength=0; //will have the length of the path
int dis=0; //stores the distance 
int path[MAX_NODES]; //an array which will store the shortest path between nodes


//function to find the shortest path of the graph
int BFS(int start,int last){ //BFS traversal with the start and the last destination
    if(start==last) {
        path[0]=start; //if the destination and the start point are the same, so path will be zero
        pathLength=1;
        dis=0;
        return 1;
    }

    int visited[MAX_NODES]={0};
    int pre[MAX_NODES];//this array will be storing the predecessors for the backtracking process
    for(int i=0;i<MAX_NODES;i++)pre[i]=-1;

    int queue[MAX_NODES]; //BFS queue
    int f=0;//front
    int r=0;//rear


    queue[r++]=start; //pushing the starting element
    visited[start]=1; //marking it as visited 
    while(f<r){//while not empty 
        int cur=queue[f++];


        
        for(int i=0;i<MAX_NODES;i++){
            if(adjMat[cur][i] && !visited[i]){
                queue[r++]=i;
                visited[i]=1;
                pre[i]=cur;

                if(i==last){
                    int x=last;
                    pathLength=0;
                    while(x!=-1){
                        path[pathLength++]=x;
                        x=pre[x];
                    }

                    for(int j=0;j<pathLength/2;j++){
                        int temp=path[j];
                        path[j]=path[pathLength-j-1];
                        path[pathLength-j-1]=temp;
                    }

                    dis=pathLength- 1; //setting the distance
                    return 1; //found the path return 1
                }



            }
        }
    }





    return 0; //didn't find it 
}



int main() {
    BuildGraph("fb-pages-sport.csv"); //make graph 
    NodeMapping("fb-pages-sportNodes.csv"); //map node labels

    
    int start;
    int last; //declaring the start and end.
    printf("Enter start vertex(0 to %d):",MAX_NODES-1); //menu-driven steps 
    if(scanf("%d",&start)!=1||start<0||start>=MAX_NODES){
        fprintf(stderr, "Invalid start vertex\n");
        return EXIT_FAILURE;
    }

    printf("Enter end vertex(0 to %d):",MAX_NODES-1);
    if(scanf("%d",&last)!=1||last<0||last>=MAX_NODES){
        fprintf(stderr,"Invalid end vertex\n");
        return EXIT_FAILURE;
    }

    int result=BFS(start,last); //calling the functions 

    if(result){ //if we get the result, then we are writing a format to print the output 
        printf("Shortest path(%d units):",dis);
        for(int i=0;i<pathLength;i++){
            if(i>0)printf("->");
            if(strlen(labels[path[i]])>0)
                printf("%s (%d)",labels[path[i]],path[i]);
            else
                printf("Node%d (%d)",path[i],path[i]);
        }
        printf("\n");


    } 
    else{ //when we didn't find the node 
        printf("No path found between %d and %d\n",start,last);
    } 
    printf("The distance is: %d\n",pathLength-1);//printing the distance;

    return 0;
}
